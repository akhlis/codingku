<template>
  <Layout class="has-sidebar docs-page" :footer="false">
    <div class="grid__wrapper flex docs">
      <div class="docs__sidebar">
        <template v-if="links" v-for="(group, i1) in links">
          <h3 class="docs__sidebar-title menu-item" :key="`title-${i1}`">{{ group.title }}</h3>
          <template v-for="(item, i2) in group.items">
            <g-link :exact="item.link == '/docs/'" class="menu-item menu-link" :to="item.link" :key="`link-${i1}-${i2}`">
              {{ item.title }}
            </g-link>
          </template>
        </template>
      </div>
      <Section class="docs__content flex-fit" container="base">
        <slot />
        <p>
          <a :href="editLink" target="_blank" class="github-edit-link">
            <Github />
            <span>Edit this page on GitHub</span>
          </a>
        </p>
        <nav class="docs-nav">
          <div class="docs-nav__previous">
            <g-link v-if="previousPage" exact class="button  button--small docs-nav__link" :to="previousPage.link">
              &larr; {{ previousPage.title }}
            </g-link>
          </div>
          <div class="docs-nav__next">
            <g-link v-if="nextPage" exact class="button  button--small docs-nav__link" :to="nextPage.link">
              {{ nextPage.title }} &rarr;
            </g-link>
          </div>
        </nav>
      </Section>
      <div v-if="subtitles.length > 0 && subtitles[0].depth !== 3" class="docs__sidebar docs__sidebar--right hide-for-small">
        <h3>On this page</h3>
        <ul v-if="subtitles.length" class="menu-item submenu">
          <li class="submenu__item" :class="'submenu__item-depth-' + subtitle.depth" v-for="subtitle in subtitles" :key="subtitle.value">
            <a class="submenu__link" :href="subtitle.anchor">
              {{ subtitle.value }}
            </a>
          </li>
        </ul>
      </div>
    </div>
  </Layout>
</template>

<script>
import Github from '~/assets/images/github-logo.svg'

export default {
  components: {
    Github
  },
  props: {
    subtitles: { type: Array, default: () => [] },
    links: { type: Array, default: () => [] }
  },
  computed: {
    currentPath () {
      return this.$route.matched[0].path
    },
    editLink () {
      let path = this.currentPath
      if((path.match(new RegExp("/", "g")) || []).length == 1) path = path + '/README'
      return `https://github.com/gridsome/gridsome.org/blob/master${path}.md`
    },
    items () {
      return this.links.reduce((acc, group) => (acc.push(...group.items), acc), [])
    },
    currentIndex () {
      return this.items.findIndex(item => {
        return item.link.replace(/\/$/, '') === this.$route.path.replace(/\/$/, '')
      })
    },
    nextPage () {
      return this.items[this.currentIndex + 1]
    },
    previousPage () {
      return this.items[this.currentIndex - 1]
    }
  }
}
</script>

<style lang="postcss" scoped>
.docs__sidebar {
  order: 2;
  z-index: 10;
  overflow: auto;
  position: relative;
  -webkit-overflow-scrolling: touch;
  padding: 1% 20px 0 5px;
  background: pink;
}

.docs__sidebar {
  &--right {
    border-right: 0;
    width: 220px;
    position: sticky;
    padding-top: 6.5%;
    top: var(--header-height);
  }

  & p {
    margin-bottom: 5px;
    font-size: 1.3rem;
  }

  & .submenu {
    list-style: none;
    margin: 0;
    font-size: .9rem;
    opacity: 1;

    &__item-depth-2 {
      margin-bottom: 0;
      padding: .4rem 0;
      font-size: .85rem;
      border-top: 1px dashed var(--border-color);
      transition: border-color .3s;
    }

    &__item-depth-3 {
      margin-bottom: 0;
      margin-top: -.4rem;
      padding: .2rem .4rem;
      font-size: .8rem;
      opacity: .8;
    }
  }
}

.docs__sidebar-title {
  font-size: 1.6rem;
  text-transform: uppercase;
  letter-spacing: 1px;
  margin: 15px 0 15px;
  padding-top: 20px;
  border-top: 1px solid var(--border-color);

  &:first-of-type {
    border: 0;
  }
}

.menu-link {
  color: var(--secondary-text-color);
  opacity: 1;
  font-weight: 400;
  display: flex;
  text-decoration: none;
  margin: 0;
  padding: .2rem 0;
  font-size: 1.4rem;

  &.active {
    color: var(--accent-color);
    position: relative;
    padding-left: 1em;

    &:before {
      content: " ";
      width: 8px;
      height: 8px;
      border-radius: 10px;
      position: absolute;
      left: -1px;
      top: 50%;
      margin-top: -5px;
      background-color: var(--accent-color);
      animation: scaleIn .7s forwards;
    }
  }

  & .active--exact {
    color: var(--accent-color);
  }

  &:hover {
    color: var(--accent-color);
  }
}

@media screen and (max-width: 850px) {
  .docs__sidebar {
    width: 100%;
    position: relative;
    margin: 0;
    order: 2;
    padding-bottom: 150px;

    &+.section {
      margin-left: 0;
      width: 100%;
    }
  }
}


@media screen and (min-width: 850px) {
  .docs__sidebar {
    position: sticky;
    border-right: 1px solid var(--border-color);
    transition: border-color .3s;
    top: var(--header-height);
    height: calc(100vh + (var(--header-height) * -1) - 5px);
    width: 260px;
    order: 0;

    &:after {
      content: "";
      position: sticky;
      display: block;
      height: 10vh;
      pointer-events: none;
      right: 0;
      bottom: 0;
      left: 0;
      width: 100%;
      background: linear-gradient(0deg, var(--main-bg) 10%, transparent);
    }
  }
}



.docs__sidebar::-webkit-scrollbar {
  width: 5px;
  position: fixed;
  right:0;
}

.docs__sidebar::-webkit-scrollbar-thumb {
  background: rgba(0,0,0,0);
  height: 80px;
  transition: background-color 2s;
}

.docs__sidebar::-webkit-scrollbar-thumb:hover,
.docs__sidebar:hover::-webkit-scrollbar-thumb {
	background:	var(--body-dark-bg);
}



.docs__content {
  padding: calc(2% + var(--space)) 0;
    position: relative;
    width: 100%;
    flex: 1;
}
.section.doc-content {
  padding-top: 2%;
}

.post {

  max-width: 100%;

  & ul li {
    margin-bottom: .5rem;
  }

  & p > img {
    margin-bottom: 0;
  }

  & h1, 
  & h2, 
  & h3 {
    padding-top: 6rem;
    margin-top: -5rem;


   & a {
      float: left;
      top: 0.12em;
      margin-left: -1.2em;
      font-size: 0.85em;
      text-align: center;
      width: 0.8em;
      opacity: 0.0;
      color: var(--primary-color);
      box-shadow: none;
      background: none;

      &::before {
        content: " ";
        position: absolute;
        top: 0;
        height: 100%;
        width: calc(100% + 0.5em);
      }

      &::after {
        display: none;
      }
    }

    &:hover a{
      opacity: 1;
    }
  }

  & h2 {
    &::before {
      content: " ";
      display: block;
      margin-bottom: 1.5rem;
      border-top: 1px solid var(--border-color);
      transition: border-color .3s;
    }
  }
  
  & h3 { opacity: .9 }

  & h4, 
  & h5, 
  & h6 { opacity: .8 }

  & h1 a, 
  & h4 a, 
  & h5 a, 
  & h6 a {
    display: none;
  }

  & p, 
  & ul {
    position: relative;
    z-index: 1;
  }

  & ul > li > p {
    font-weight: 400;
  }
}




.github-edit-link {
  font-size: .9rem;
  font-weight: normal;
  display: flex;
  align-items: center;
  padding-top: 1rem;
  
  &:not(:hover) {
    color: var(--primary-color);
  }

  svg {
    margin-right: .5rem;
  }
}

.docs-nav {
  display: flex;
  justify-content: space-between;
  border-top: 1px solid var(--border-color);

  &__title {
    margin: 0;
    font-size: 0.75em;
  }

  &__link {
    border: 1px solid var(--border-color);
  }
}
</style>
